package com.arvind.lanwrite

import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

object Proto {
    const val DISC = 45454          // UDP discovery
    const val TCP = 45455           // file transfer
    const val LIVE_MS = 30_000L     // hide device if silent this long
    const val RETRY_MS = 10_000L    // retry period for failed sends
    const val WRITE_PKG = "com.styluslabs.writeqt"   // Stylus Labs Write
}

class Device(val id: String, val name: String, val ip: String, val port: Int, val seen: Long)

class Job(val id: Long, val file: File, val name: String, val devId: String, val devName: String, val overwrite: Boolean) {
    val size: Long = file.length()
    @Volatile var sent = 0L
    @Volatile var state = "Queued"
    @Volatile var done = false
    @Volatile var running = false
    @Volatile var nextTry = 0L
    @Volatile var tries = 0
}

class PendingSend(val mode: String, val devIds: Set<String>, val ow: Boolean, val expires: Long)

object Hub {
    @Volatile var pending: PendingSend? = null   // what to do with the next file Write exports
    @Volatile var busyUntil = 0L                  // floating button hides while automation taps Write's menu
    val devices = ConcurrentHashMap<String, Device>()
    val jobs = CopyOnWriteArrayList<Job>()
    val seq = AtomicLong()
    @Volatile var myId = ""
    @Volatile var myName = ""
    @Volatile var watcherOn = false     // accessibility watcher running
    @Volatile var fgPkg = ""            // app currently in front (when watcherOn)
    fun live(): List<Device> {
        val now = System.currentTimeMillis()
        return devices.values.filter { now - it.seen < Proto.LIVE_MS }.sortedBy { it.name.lowercase() }
    }
}

object Forward {
    /** open the installed LAN Share (chosen in the menu) with the file already attached */
    fun toLanShare(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).setType("text/html").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        i.clipData = ClipData.newRawUri("", uri)
        val pkg = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("lspkg", null)
        if (pkg != null) { i.setPackage(pkg); ctx.startActivity(i) }
        else ctx.startActivity(Intent.createChooser(i, "Send with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
