package com.arvind.lanwrite

import android.app.Service
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs

/** Small draggable button over Write. Tap = panel: tick devices, then it drives Write's Share > Send HTML and forwards the exported file. */
class Overlay(private val svc: Service) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = svc.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val ui = Handler(Looper.getMainLooper())
    private var btn: TextView? = null
    private var btnLp: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var devBox: LinearLayout? = null
    private var title: TextView? = null
    private var status: TextView? = null
    private var lastKey = "?"
    private val sel = HashSet<String>()

    private fun dp(n: Int) = (n * svc.resources.displayMetrics.density).toInt()
    private val size get() = dp(52)
    @Suppress("DEPRECATION")
    private val winType: Int get() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun toast(s: String) = Toast.makeText(svc, s, Toast.LENGTH_LONG).show()

    /** called every second from the service */
    fun update() {
        try {
            val want = prefs.getBoolean("overlay", false) && Settings.canDrawOverlays(svc) &&
                Hub.watcherOn && Hub.fgPkg == Proto.WRITE_PKG && System.currentTimeMillis() > Hub.busyUntil
            if (want && btn == null) showButton()
            if (!want && btn != null) hideAll()
            if (panel != null) refreshPanel()
        } catch (e: Exception) { }
    }

    private fun showButton() {
        val dm = svc.resources.displayMetrics
        val b = TextView(svc).apply {
            text = "➤"; gravity = Gravity.CENTER; textSize = 22f; setTextColor(Color.WHITE); alpha = 0.92f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE60A5AB0.toInt()); setStroke(dp(2), Color.WHITE) }
            elevation = dp(6).toFloat()
        }
        val lp = WindowManager.LayoutParams(size, size, winType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("ox", dm.widthPixels - size - dp(12)).coerceIn(0, dm.widthPixels - size)   // remembered position
            y = prefs.getInt("oy", dp(96)).coerceIn(0, dm.heightPixels - size)
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (!prefs.getBoolean("lockpos", false) && (abs(e.rawX - dx) > dp(8) || abs(e.rawY - dy) > dp(8))) moved = true
                    if (moved) {
                        lp.x = (sx + e.rawX - dx).toInt().coerceIn(0, dm.widthPixels - size)
                        lp.y = (sy + e.rawY - dy).toInt().coerceIn(0, dm.heightPixels - size)
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("ox", lp.x).putInt("oy", lp.y).apply()
                    else if (panel != null) closePanel() else openPanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, lp); btn = b; btnLp = lp
    }

    private fun hideAll() {
        closePanel()
        btn?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        btn = null
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null; devBox = null; title = null; status = null; lastKey = "?"
    }

    private fun small(t: String, onClick: () -> Unit) = Button(svc).apply {
        text = t; isAllCaps = false; textSize = 13f; minHeight = dp(40); minimumHeight = dp(40)
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setOnClickListener { onClick() }
    }

    private fun openPanel() {
        val lp0 = btnLp ?: return
        val dm = svc.resources.displayMetrics
        val dark = 0xFF16202A.toInt()
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10)); elevation = dp(10).toFloat()
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0xFFB8C4CE.toInt()) }
        }
        title = TextView(svc).apply { text = "Send the document open in Write"; setTextColor(dark); textSize = 15f; setTypeface(typeface, Typeface.BOLD) }
        devBox = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(svc).apply { setTextColor(0xFF5B6A77.toInt()); textSize = 12f }
        p.addView(title); p.addView(devBox); p.addView(status)
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(small("Send to selected") { startExport("dev") })
        row.addView(small("LAN Share app") { startExport("app") })
        p.addView(row)
        val row2 = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(small("Teach steps") { teach() })
        row2.addView(small("Close") { closePanel() })
        p.addView(row2)

        val w = minOf(dp(320), dm.widthPixels - dp(24))
        val lp = WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT, winType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (lp0.x + size / 2 - w / 2).coerceIn(dp(8), maxOf(dp(8), dm.widthPixels - w - dp(8)))
            y = if (lp0.y > dm.heightPixels / 2) maxOf(dp(8), lp0.y - dp(340)) else lp0.y + size + dp(8)
        }
        wm.addView(p, lp); panel = p
        refreshPanel()
    }

    private fun refreshPanel() {
        val box = devBox ?: return
        val live = Hub.live(); val key = live.joinToString(",") { it.id }
        if (key != lastKey) {
            lastKey = key; box.removeAllViews()
            if (live.isEmpty()) box.addView(TextView(svc).apply { text = "No devices online yet…"; setTextColor(0xFF5B6A77.toInt()); setPadding(0, dp(8), 0, dp(8)) })
            for (d in live) box.addView(CheckBox(svc).apply {
                text = d.name; setTextColor(0xFF16202A.toInt()); isChecked = d.id in sel
                setOnCheckedChangeListener { _, c -> if (c) sel.add(d.id) else sel.remove(d.id) }
            })
        }
        status?.text = Hub.jobs.toList().takeLast(4).joinToString("\n") {
            val pct = if (it.size > 0) (it.sent * 100 / it.size).toInt() else 0
            "${it.devName}: ${it.state}" + if (it.state == "Sending") " $pct%" else ""
        }
    }

    private fun startExport(mode: String) {
        val w = WatcherService.inst
        if (w == null) { toast("Turn on “LAN Write: detect Write” in Accessibility settings first."); return }
        if (mode == "dev" && sel.isEmpty()) { toast("Tick at least one device"); return }
        val now = System.currentTimeMillis()
        Hub.pending = PendingSend(mode, HashSet(sel), prefs.getBoolean("ow", false), now + 40_000)
        Hub.busyUntil = now + 20_000          // hide this button so it cannot cover Write's menu
        closePanel()
        toast("Exporting from Write…")
        w.runExport { err -> Hub.pending = null; Hub.busyUntil = 0; toast(err) }
    }

    private fun teach() {
        val w = WatcherService.inst
        if (w == null) { toast("Turn on “LAN Write: detect Write” in Accessibility settings first."); return }
        closePanel(); Hub.busyUntil = System.currentTimeMillis() + 60_000
        w.calibrate { msg -> Hub.busyUntil = 0; toast(msg) }
    }
}
