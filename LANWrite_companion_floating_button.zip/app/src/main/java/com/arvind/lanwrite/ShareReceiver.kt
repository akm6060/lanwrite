package com.arvind.lanwrite

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import java.io.File

/** Invisible share target. Write's  Menu > Share > Send HTML  lands here; the file is forwarded automatically. */
class ShareReceiver : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Thread {
            val f = try { grab() } catch (e: Exception) { null }
            runOnUiThread { try { route(f) } finally { finish() } }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun grab(): File? {
        val dir = File(filesDir, "outbox/${System.currentTimeMillis()}").apply { mkdirs() }
        val uri: Uri? = intent.getParcelableExtra(Intent.EXTRA_STREAM)
            ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        if (uri != null) {
            var name: String? = null
            try { contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) { val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = c.getString(ix) } } } catch (e: Exception) { }
            var n = File(name ?: uri.lastPathSegment ?: "document.html").name
            if (!n.contains('.')) n += ".html"
            val f = File(dir, n)
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            return f
        }
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        if (text != null && text.contains("<")) return File(dir, "document.html").apply { writeText(text) }
        return null
    }

    private fun route(f: File?) {
        if (f == null) { Toast.makeText(this, "Write sent no file", Toast.LENGTH_LONG).show(); return }
        val p = Hub.pending
        if (p != null && System.currentTimeMillis() < p.expires) {
            Hub.pending = null; Hub.busyUntil = 0
            if (p.mode == "dev") {
                var n = 0
                for (id in p.devIds) {
                    val d = Hub.devices[id]
                    Hub.jobs.add(Job(Hub.seq.incrementAndGet(), f, f.name, id, d?.name ?: id, p.ow)); n++
                }
                Toast.makeText(this, "Sending ${f.name} to $n device(s)", Toast.LENGTH_LONG).show()
            } else {
                try { Forward.toLanShare(this, f) } catch (e: Exception) { Toast.makeText(this, "Cannot open LAN Share: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        } else {
            startActivity(Intent(this, MainActivity::class.java).putExtra("staged", f.absolutePath)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }
}
