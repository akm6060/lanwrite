package com.arvind.lanwrite

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView

/**
 * 1) tells us which app is in front (floating button shows only over Write)
 * 2) runs Write's  Menu > Share > Send HTML  for you (taps you taught once, or label match when Write exposes labels)
 * 3) picks "LAN Write" in the share sheet.
 * It only looks for those labels while an export is running.
 */
class WatcherService : AccessibilityService() {
    companion object { @Volatile var inst: WatcherService? = null }
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    private val labels = listOf<String?>(null, "Share", "Send HTML")
    private val prompts = listOf("Tap Write’s menu button\n(step 1 of 3)", "Tap “Share”\n(step 2 of 3)", "Tap “Send HTML”\n(step 3 of 3)")

    override fun onServiceConnected() { Hub.watcherOn = true; inst = this }
    override fun onUnbind(i: Intent?): Boolean { Hub.watcherOn = false; inst = null; return super.onUnbind(i) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val p = e.packageName?.toString() ?: return
        if (p == packageName || p == "com.android.systemui") return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (imm.enabledInputMethodList.any { it.packageName == p }) return      // keyboard must not hide the button
        Hub.fgPkg = p
    }

    @Suppress("DEPRECATION")
    private fun real(): DisplayMetrics { val m = DisplayMetrics(); (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m); return m }
    private fun orient(m: DisplayMetrics) = if (m.widthPixels > m.heightPixels) "l" else "p"

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }

    private fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun tapSaved(i: Int): Boolean {
        val m = real(); val k = "t" + orient(m) + i
        if (!prefs.contains(k + "x")) return false
        tapAt(prefs.getFloat(k + "x", 0f) * m.widthPixels, prefs.getFloat(k + "y", 0f) * m.heightPixels)
        return true
    }

    /** Write > Menu > Share > Send HTML, then choose LAN Write in the share sheet. onError is called on the main thread. */
    fun runExport(onError: (String) -> Unit) {
        fun step(i: Int) {
            if (i == labels.size) { h.postDelayed({ chooser(0, onError) }, 700); return }
            val ok = (labels[i]?.let { clickText(it) } == true) || tapSaved(i)
            if (!ok) { onError("First tap “Teach steps” in the panel and show me Write’s Share > Send HTML path."); return }
            h.postDelayed({ step(i + 1) }, 850)
        }
        step(0)
    }

    private fun chooser(n: Int, onError: (String) -> Unit) {
        if (clickText("LAN Write")) return
        if (n >= 20) { onError("Could not find LAN Write in the share sheet."); return }
        h.postDelayed({ chooser(n + 1, onError) }, 400)
    }

    /** you tap the three steps once; each tap is remembered (per screen orientation) and passed through to Write */
    fun calibrate(done: (String) -> Unit) = calStep(0, done)

    private fun calStep(i: Int, done: (String) -> Unit) {
        if (i == 3) { h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK); done("Steps saved") }, 1500); return }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = prompts[i]; gravity = Gravity.CENTER; textSize = 22f; setTextColor(Color.WHITE); setBackgroundColor(0x77000000)
        }
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val m = real(); val k = "t" + orient(m) + i
                prefs.edit().putFloat(k + "x", e.rawX / m.widthPixels).putFloat(k + "y", e.rawY / m.heightPixels).apply()
                val x = e.rawX; val y = e.rawY
                try { wm.removeView(tv) } catch (ex: Exception) { }
                h.postDelayed({ tapAt(x, y); h.postDelayed({ calStep(i + 1, done) }, 950) }, 150)
            }
            true
        }
        wm.addView(tv, lp)
    }
}
