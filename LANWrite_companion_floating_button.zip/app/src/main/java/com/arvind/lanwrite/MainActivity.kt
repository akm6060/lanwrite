package com.arvind.lanwrite

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.app.AlertDialog
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val picked = HashSet<String>()
    private var pending: File? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var info: TextView
    private lateinit var cbOw: CheckBox
    private lateinit var devAd: BaseAdapter
    private lateinit var jobAd: BaseAdapter
    private var devs: List<Device> = emptyList()
    private var jobs: List<Job> = emptyList()

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, ShareService::class.java))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        info = TextView(this); root.addView(info)

        cbOw = CheckBox(this).apply { text = "Overwrite if the file already exists on the target"; isChecked = prefs.getBoolean("ow", false); setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("ow", c).apply() } }
        root.addView(cbOw)
        root.addView(Switch(this).apply {
            text = "Start automatically after phone restart"
            isChecked = prefs.getBoolean("autostart", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("autostart", c).apply() }
        })
        root.addView(Button(this).apply {
            text = "Allow unrestricted background use"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            }
        })

        root.addView(TextView(this).apply { text = "Devices on this Wi-Fi (tap to select)"; setPadding(0, dp(8), 0, 0) })
        val devList = ListView(this)
        devAd = object : BaseAdapter() {
            override fun getCount() = devs.size
            override fun getItem(i: Int) = devs[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val t = (v as? TextView) ?: TextView(this@MainActivity).apply { setPadding(dp(8), dp(10), dp(8), dp(10)); textSize = 16f }
                val d = devs[i]; t.text = (if (d.id in picked) "☑  " else "☐  ") + d.name + "   " + d.ip; return t
            }
        }
        devList.adapter = devAd
        devList.setOnItemClickListener { _, _, i, _ ->
            val d = devs.getOrNull(i) ?: return@setOnItemClickListener
            if (!picked.add(d.id)) picked.remove(d.id); devAd.notifyDataSetChanged()
        }
        root.addView(devList, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(Button(this).apply { text = "Send to selected devices"; setOnClickListener { doSend() } })

        root.addView(TextView(this).apply { text = "Transfers" })
        val jobList = ListView(this)
        jobAd = object : BaseAdapter() {
            override fun getCount() = jobs.size
            override fun getItem(i: Int) = jobs[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val ctx = this@MainActivity
                val row = (v as? LinearLayout) ?: LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6))
                    addView(TextView(ctx))
                    addView(ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 })
                }
                val j = jobs[i]
                val pct = if (j.done && j.state == "Done") 100 else if (j.size > 0) (j.sent * 100 / j.size).toInt() else 0
                (row.getChildAt(0) as TextView).text = "${j.name} → ${j.devName}\n${j.state}  $pct%"
                (row.getChildAt(1) as ProgressBar).progress = pct
                return row
            }
        }
        jobList.adapter = jobAd
        root.addView(jobList, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        updateInfo()
        handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); handle(i) }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        if (i == null) return
        i.getStringExtra("staged")?.let { pending = File(it); updateInfo() }
        val uri: Uri? = when (i.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri != null) stage(uri)
    }

    // ---- 3-dot menu ----
    override fun onCreateOptionsMenu(m: Menu): Boolean {
        m.add(0, 1, 0, "Document…")
        m.add(0, 2, 1, "Receive folder…")
        m.add(0, 3, 9, "Clear finished")
        m.add(0, 5, 3, "LAN Share app…")
        m.add(0, 6, 4, "Floating button over Write").isCheckable = true
        m.add(0, 7, 5, "Lock button position").isCheckable = true
        m.add(0, 8, 6, "Turn on Write helper (accessibility)…")
        return true
    }

    override fun onPrepareOptionsMenu(m: Menu): Boolean {
        m.findItem(6)?.isChecked = prefs.getBoolean("overlay", false)
        m.findItem(7)?.isChecked = prefs.getBoolean("lockpos", false)
        return true
    }

    private fun pickLanShare() {
        val ris = packageManager.queryIntentActivities(Intent(Intent.ACTION_SEND).setType("text/html"), 0)
            .filter { it.activityInfo.packageName != packageName }.distinctBy { it.activityInfo.packageName }
        val labels = (listOf("Ask every time") + ris.map { it.loadLabel(packageManager).toString() }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Which app is LAN Share?").setItems(labels) { _, i ->
            prefs.edit().apply { if (i == 0) remove("lspkg") else putString("lspkg", ris[i - 1].activityInfo.packageName) }.apply()
        }.show()
    }

    override fun onOptionsItemSelected(it: MenuItem): Boolean {
        when (it.itemId) {
            1 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 10)
            2 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 11)
            3 -> Hub.jobs.removeIf { j -> j.done }
            5 -> pickLanShare()
            6 -> {
                val on = !prefs.getBoolean("overlay", false); prefs.edit().putBoolean("overlay", on).apply()
                if (on && !Settings.canDrawOverlays(this)) {
                    toast("Allow “Display over other apps” for LAN Write, then come back.")
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
            7 -> prefs.edit().putBoolean("lockpos", !prefs.getBoolean("lockpos", false)).apply()
            8 -> { toast("Turn on “LAN Write: detect Write”. If it is greyed out: App info > ⋮ > Allow restricted settings."); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        return true
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (req == 10) stage(uri)
        if (req == 11) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs.edit().putString("folder", uri.toString()).apply(); updateInfo()
        }
    }

    private fun stage(uri: Uri) {
        Thread {
            try {
                var name = "document.html"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) { val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = c.getString(ix) }
                }
                val dir = File(filesDir, "outbox/${System.currentTimeMillis()}").apply { mkdirs() }
                val f = File(dir, File(name).name)
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { pending = f; updateInfo() }
            } catch (e: Exception) { runOnUiThread { toast("Cannot read file: ${e.message}") } }
        }.start()
    }

    private fun doSend() {
        val f = pending
        if (f == null) { toast("Choose a document first: menu ⋮ → Document…"); return }
        val sel = picked.mapNotNull { Hub.devices[it] }
        if (sel.isEmpty()) { toast("Select at least one device"); return }
        for (d in sel) Hub.jobs.add(Job(Hub.seq.incrementAndGet(), f, f.name, d.id, d.name, cbOw.isChecked))
        prefs.edit().putBoolean("ow", cbOw.isChecked).apply()
    }

    private fun updateInfo() {
        val folder = prefs.getString("folder", null)?.let { Uri.parse(it).lastPathSegment } ?: "app folder (Android/data/$packageName/files/Received)"
        info.text = "Document: ${pending?.name ?: "none — menu ⋮ → Document…"}\nReceive folder: $folder"
    }

    private val tick = object : Runnable {
        override fun run() {
            devs = Hub.live(); jobs = Hub.jobs.toList()
            devAd.notifyDataSetChanged(); jobAd.notifyDataSetChanged()
            ui.postDelayed(this, 500)
        }
    }
    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
}
