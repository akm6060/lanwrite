package com.arvind.lanwrite

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.*
import java.net.*
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Always-on foreground service: discovery beacons, discovery listener, TCP receiver, retrying sender. */
class ShareService : Service() {
    private val started = AtomicBoolean(false)
    private val pool = Executors.newCachedThreadPool()
    private var lastNotif = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        goForeground("Listening for devices")
        if (started.compareAndSet(false, true)) boot()
        return START_STICKY
    }

    private fun goForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("svc", "LAN Write", NotificationManager.IMPORTANCE_LOW))
        val n = builder(text).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun builder(text: String) = NotificationCompat.Builder(this, "svc")
        .setSmallIcon(android.R.drawable.stat_sys_upload)
        .setContentTitle("LAN Write")
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))

    private fun refreshNotif(j: Job? = null) {
        val pending = Hub.jobs.count { !it.done }
        val sending = j != null && j.state == "Sending"
        val b = builder(
            if (sending) "Sending ${j!!.name} → ${j.devName}"
            else if (pending > 0) "$pending file(s) pending"
            else "Listening • ${Hub.live().size} device(s) online"
        )
        if (sending && j!!.size > 0) b.setProgress(100, (j.sent * 100 / j.size).toInt(), false)
        getSystemService(NotificationManager::class.java).notify(1, b.build())
    }

    @Suppress("DEPRECATION")
    private fun boot() {
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        var id = p.getString("id", null)
        if (id == null) { id = UUID.randomUUID().toString(); p.edit().putString("id", id).apply() }
        Hub.myId = id
        Hub.myName = p.getString("name", null) ?: Build.MODEL

        // keep CPU + Wi-Fi awake, allow UDP broadcast reception (battery use ignored on purpose)
        (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lanwrite:svc").apply { setReferenceCounted(false); acquire() }
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifi.createMulticastLock("lanwrite").apply { setReferenceCounted(false); acquire() }
        wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lanwrite").apply { setReferenceCounted(false); acquire() }

        val ov = Overlay(this); val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable { override fun run() { ov.update(); h.postDelayed(this, 1000) } })
        for (t in listOf(::beaconLoop, ::discoveryLoop, ::serverLoop, ::senderLoop)) Thread { t() }.apply { isDaemon = true }.start()
    }

    // ---------- discovery ----------
    private fun beaconBytes() = JSONObject().put("app", "lanwrite").put("id", Hub.myId)
        .put("name", Hub.myName).put("port", Proto.TCP).toString().toByteArray()

    @Suppress("DEPRECATION")
    private fun subnetBroadcast(): InetAddress? = try {
        val d = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).dhcpInfo
        if (d.ipAddress == 0) null else {
            val b = (d.ipAddress and d.netmask) or d.netmask.inv()
            InetAddress.getByAddress(byteArrayOf((b and 255).toByte(), (b shr 8 and 255).toByte(), (b shr 16 and 255).toByte(), (b shr 24 and 255).toByte()))
        }
    } catch (e: Exception) { null }

    private fun beaconLoop() {
        while (true) try {
            val s = DatagramSocket(); s.broadcast = true
            while (true) {
                val data = beaconBytes()
                for (a in listOfNotNull(InetAddress.getByName("255.255.255.255"), subnetBroadcast()))
                    try { s.send(DatagramPacket(data, data.size, a, Proto.DISC)) } catch (e: Exception) { }
                if (Hub.jobs.none { it.running }) refreshNotif()
                Thread.sleep(3000)
            }
        } catch (e: Exception) { Thread.sleep(3000) }
    }

    private fun discoveryLoop() {
        while (true) try {
            val s = DatagramSocket(null); s.reuseAddress = true; s.bind(InetSocketAddress(Proto.DISC)); s.broadcast = true
            val buf = ByteArray(2048)
            while (true) {
                val pk = DatagramPacket(buf, buf.size); s.receive(pk)
                try {
                    val j = JSONObject(String(pk.data, 0, pk.length))
                    if (j.optString("app") != "lanwrite") continue
                    val id = j.getString("id"); if (id == Hub.myId) continue
                    val ip = pk.address.hostAddress ?: continue
                    val now = System.currentTimeMillis()
                    val old = Hub.devices[id]
                    val isNew = old == null || now - old.seen > Proto.LIVE_MS
                    Hub.devices[id] = Device(id, j.optString("name", ip), ip, j.getInt("port"), now)
                    if (isNew) pool.execute {   // instant two-way discovery: answer a newcomer right away
                        try { val d = beaconBytes(); DatagramSocket().use { it.send(DatagramPacket(d, d.size, pk.address, Proto.DISC)) } } catch (e: Exception) { }
                    }
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { Thread.sleep(2000) }
    }

    // ---------- receive ----------
    private class Exists : Exception()
    private class Sink(val out: OutputStream, val discard: () -> Unit)

    private fun openSink(name: String, ow: Boolean): Sink {
        val tree = getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("folder", null)
        if (tree != null) {
            val dir = DocumentFile.fromTreeUri(this, Uri.parse(tree))
            if (dir != null && dir.canWrite()) {
                val ex = dir.findFile(name)
                if (ex != null) { if (!ow) throw Exists(); ex.delete() }
                val f = dir.createFile("application/octet-stream", name) ?: throw IOException("cannot create file")
                return Sink(contentResolver.openOutputStream(f.uri)!!) { f.delete() }
            }
        }
        val dir = File(getExternalFilesDir(null), "Received").apply { mkdirs() }
        val f = File(dir, name)
        if (f.exists()) { if (!ow) throw Exists(); f.delete() }
        return Sink(FileOutputStream(f)) { f.delete() }
    }

    private fun serverLoop() {
        while (true) try {
            val ss = ServerSocket(); ss.reuseAddress = true; ss.bind(InetSocketAddress(Proto.TCP))
            while (true) { val c = ss.accept(); pool.execute { try { receive(c) } catch (e: Exception) { } } }
        } catch (e: Exception) { Thread.sleep(2000) }
    }

    private fun receive(c: Socket) {
        c.use { s ->
            s.soTimeout = 30_000
            val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 65536)); val out = s.getOutputStream()
            val hl = inp.readInt(); if (hl !in 1..65536) return
            val hb = ByteArray(hl); inp.readFully(hb)
            val h = JSONObject(String(hb))
            val name = File(h.getString("name")).name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file.html" }
            val size = h.getLong("size"); val ow = h.optBoolean("overwrite", false)
            val sink = try { openSink(name, ow) }
            catch (e: Exists) { out.write(1); out.flush(); return }
            catch (e: Exception) { out.write(2); out.flush(); return }
            out.write(0); out.flush()
            var ok = false
            try {
                val buf = ByteArray(65536); var left = size
                while (left > 0) {
                    val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw EOFException()
                    sink.out.write(buf, 0, n); left -= n
                }
                sink.out.flush(); ok = true
            } finally { try { sink.out.close() } catch (e: Exception) { }; if (!ok) sink.discard() }
            out.write(0); out.flush()
            getSystemService(NotificationManager::class.java).notify(2, builder("Received $name").setOngoing(false).build())
        }
    }

    // ---------- send with automatic retry ----------
    private fun senderLoop() {
        while (true) {
            try {
                val now = System.currentTimeMillis()
                for (j in Hub.jobs) if (!j.done && !j.running && now >= j.nextTry) {
                    j.running = true
                    pool.execute { try { send(j) } finally { j.running = false } }
                }
            } catch (e: Exception) { }
            Thread.sleep(1000)
        }
    }

    private fun fail(j: Job, why: String) {
        j.nextTry = System.currentTimeMillis() + Proto.RETRY_MS
        j.state = "Retrying in ${Proto.RETRY_MS / 1000}s ($why)"
    }

    private fun send(j: Job) {
        val d = Hub.devices[j.devId]
        if (d == null || System.currentTimeMillis() - d.seen > Proto.LIVE_MS) { fail(j, "device offline"); return }
        j.tries++; j.state = "Connecting"; j.sent = 0
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(d.ip, d.port), 5000); s.soTimeout = 30_000
                val out = BufferedOutputStream(s.getOutputStream(), 65536); val inp = s.getInputStream()
                val h = JSONObject().put("name", j.name).put("size", j.size).put("overwrite", j.overwrite).put("from", Hub.myName).toString().toByteArray()
                DataOutputStream(out).apply { writeInt(h.size); write(h); flush() }
                when (inp.read()) {
                    0 -> {}
                    1 -> { j.state = "Skipped – file already exists there"; j.done = true; return }
                    else -> throw IOException("receiver refused")
                }
                j.state = "Sending"
                FileInputStream(j.file).use { f ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val n = f.read(buf); if (n < 0) break
                        out.write(buf, 0, n); j.sent += n
                        val t = System.currentTimeMillis(); if (t - lastNotif > 700) { lastNotif = t; refreshNotif(j) }
                    }
                }
                out.flush()
                if (inp.read() != 0) throw IOException("no confirmation")
                j.sent = j.size; j.state = "Done"; j.done = true
            }
        } catch (e: Exception) { fail(j, e.message ?: e.javaClass.simpleName) }
        refreshNotif()
    }
}
