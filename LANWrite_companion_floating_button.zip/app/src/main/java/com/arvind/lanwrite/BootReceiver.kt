package com.arvind.lanwrite

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("autostart", true))
            ContextCompat.startForegroundService(c, Intent(c, ShareService::class.java))
    }
}
