plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.arvind.lanwrite"
    compileSdk = 34
    defaultConfig { applicationId = "com.arvind.lanwrite"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
}
